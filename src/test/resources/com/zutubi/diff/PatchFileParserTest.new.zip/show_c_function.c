int Lorem(ipsum) {
  dolor sit = amet, consectetur;

  adipisicing elit, sed;

  do {
    eiusmod(tempor);
    incididunt = utwo;
  } labore(et < dolore);

  magna aliqua;
}
